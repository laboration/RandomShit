package lab5.simulator;

import java.util.Observable;

/**
 * En klass som beskriver tillståndet "just nu" i en simulering
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public class State extends Observable {
	private double timeCurrent, timePast;
	public boolean flag;
	private EventQueue queue;
	
	/**
	 * Konstruktor. Skapar ett objekt av typen State med parametrarna time, flag och queue
	 * @param time
	 * @param flag
	 * @param queue
	 */
	public State() {
	}
	
	public void stopSim() {
		this.flag = false;
	}
	
	/**
	 * Returnerar den nuvarande tiden för tillståndet
	 * @return
	 */
	public double getTimeCurrent() {
		return this.timeCurrent;
	}
	
	/**
	 * Slår fast tiden för tillståndet
	 * @param setTime
	 */
	public void setTimeCurrent(double setTime) {
		this.timePast = this.timeCurrent;
		this.timeCurrent = setTime;
	}
	
	public double getTimePast() {
		return this.timePast;
	}
	
	/**
	 * Returnerar kön av event för tillståndet
	 * @return
	 */
	public EventQueue getEventQueue() {
		return this.queue;
	}
	
	public void update() {
		setChanged();
		notifyObservers();
	}
}	