package lab5.store;

import lab5.simulator.View;

import java.util.Observable;
import java.util.Observer;

import lab5.Options;
import lab5.store.StoreState;

import java.text.DecimalFormat;
public class StoreView extends View implements Observer {
	
	private StoreState state;
	private DecimalFormat decFormat1 = new DecimalFormat("0.00");
	private DecimalFormat decFormat2 = new DecimalFormat("0.0");
	
	public StoreView(StoreState state) {
		super(state);
		this.state = state;
		state.addObserver(this);
	}

	//Parametrar
	public void printStart() {
			System.out.println("PARAMETRAR");
			System.out.println("==========");
			System.out.println("Antal kassor, N.......: "+Options.getCashierMax());
			System.out.println("Max som rymms, M.......: "+Options.getCustomersMax());
			System.out.println("Ankomsthastighet, lambda......: "+decFormat2.format(Options.getLambda()));
			System.out.println("Plocktider[P_min..Pmax] ["+Options.getPlockMin()+".."+Options.getPlockMax()+"]");
			System.out.println("Betaltider[K_min..Kmax] ["+Options.getPayMin()+".."+Options.getPayMax()+"]");
			System.out.println("Frö,f  "+Options.getSeed());
			System.out.println("");
			System.out.println("FÖRLOPP  ");
			System.out.println("=======");
			System.out.println("Tid\tHändelse \tKund\t?\tled\tledT\tKunder\tTot\tMissade\tköat\tKöatT\tköar\t[Kassakö..]");
			System.out.println(decFormat1.format(Options.getStartTime())+"  "+"\t START");
		}		

		
	//Alla event	
	public void printEvents() {
		if(state.getEventPast() == "CLOSING") {
			
			System.out.println(
					decFormat1.format(state.getTimeCurrent())+ 
					"\t"+state.getEventPast()+"  "+
					"\t"+"-"+
					"\t"+state.getOpenPast()+
					"\t"+state.getCashierNrPast()+
					"\t"+decFormat1.format(state.getTimeEmptyCashier())+"  "+
					"\t"+state.getCustomersPast()+
					"\t"+state.getCustomersDonePast()+
					"\t"+state.getCustomersMissedPast()+
					"\t"+state.getQueueSizePast()+
					"\t"+decFormat1.format(state.getTimeInQueue())+
					"\t"+state.getCustomerQueueSizePast()+
					"\t["+state.getPayQueuePast().toString()+"]"
				);
			
		} else {
		
		System.out.println(
				decFormat1.format(state.getTimeCurrent())+ 
				"\t"+state.getEventPast()+"  "+
				"\t"+state.getCustomerPast().findCustomer()+
				"\t"+state.checkOpenCurrent()+
				"\t"+state.getCashierNrPast()+
				"\t"+decFormat1.format(state.getTimeEmptyCashier())+"  "+
				"\t"+state.getCustomersPast()+
				"\t"+state.getCustomersDonePast()+
				"\t"+state.getCustomersMissedPast()+
				"\t"+state.getQueueSizePast()+
				"\t"+decFormat1.format(state.getTimeInQueue())+
				"\t"+state.getCustomerQueueSizePast()+
				"\t["+state.getPayQueuePast()+"]"
			);
		}		
		
	}
	
	public void printClosing() {
		System.out.println("TID  "+"HÄNDELSE  ");
	}
	//Resultat		
	public void printSummary() {
		
		System.out.println(decFormat1.format(Options.getStopTime())+"\tStop");
		System.out.println("");
		System.out.println("RESULTAT");
		System.out.println("========");
		System.out.println(
		"1) Av "+
		//totalt antal kunder
		(state.getCustomersDoneCurrent()+state.getCustomersMissedCurrent())
		+" kunder handlade "
		//antal kunder som handlat
		+state.getCustomersDoneCurrent()
		+" medan "
		//antal kunder som missades
		+state.getCustomersMissedCurrent()
		+" missades."
				);
		System.out.println("");
		System.out.println(
		"2) Total tid "
		//antal kassor lediga
		+Options.getCashierMax()
		+" kassor varit lediga: "
		//total tid dom kassor varit lediga
		+decFormat1.format(state.getTimeEmptyCashier())
		+" te. \n"
		+"   Genomsnittlig ledig kassatid: "
		//Genomsnittlig tid
		+decFormat1.format(state.getTimeEmptyCashier()/state.getCashierNr())
		+" te (dvs "
		+decFormat1.format(100*(state.getTimeEmptyCashier()/Options.getCashierMax()/state.getTimeEventPast()))
		+"% av tiden från öppning tills sista kunden betalat). \n"
				);
		System.out.println(
		"3) Total tid "
		+state.getQueueSizeTotal()
		+" kunder tvingats köa: "
		+decFormat1.format(state.getTimeInQueue())
		+" te. \n"
		+"   Genomsnittlig kötid: "
		+decFormat1.format(state.getTimeInQueue()/state.getQueueSizeTotal())
		+" te."
		
				);	
		
	}
	
	public void update(Observable arg0, Object arg1) {	
		printEvents();
	}
}
