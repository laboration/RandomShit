package lab5.store.events;

import lab5.store.StoreState;
import lab5.simulator.Event;
import lab5.simulator.EventQueue;
import lab5.store.Customer;
/**
 * En klass som skapar specifika eventet Arrival (ankomst)
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public class Arrival extends Event {
	private Customer customer;
	private StoreState state;
	
	/**
	 * Konstruktorn kallar på konstruktorn för event, med parametrarna time, storeState och eventQueue och ger det namn och tillstånd
	 * @param time eventets tidpunkt
	 * @param storeState tillståndet just nu
	 * @param eventQueue kön just nu
	 */
	public Arrival(double time, StoreState storeState, EventQueue eventQueue) {
		super(time, storeState, eventQueue);
		this.NAME = "ARRIVAL";
		this.state = storeState;
	}
	
	/**
	 * Skapar en ny kund, sätter en ny tid, förra kund och förra event
	 * Kontrollerar om snabbköpet är öppet och läggder till kunder om så är fallet
	 * Om snabbköpet är fullt ökar customersMissed med ett.
	 * Gerenerar nästa ankomst och lägger till den i kön av event. 
	 */
	public void run() {
		customer = state.newCustomer(); // Creates a new customer.
		state.setTimeCurrent(eventTime);
		state.setCustomerPast(customer);
		state.setEventPast(NAME);

		if (state.checkOpenCurrent()) {
			if (state.checkCustomersNotMax()) {

				state.increaseCustomers();
				eventQueue.addEvent(
						new Shopping(state.getRandomShoppingTime(), state, eventQueue, customer));

			} else {
				state.increaseMissed();
			}
			eventQueue.addEvent(new Arrival(state.getRandomArrivalTime(), state, eventQueue));
		}
		// Om snabbköpet är stängt händer ingenting.
	}
}