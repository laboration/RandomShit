package lab5.store;
import lab5.simulator.Event;
import lab5.simulator.EventQueue;
import lab5.simulator.State;

public abstract class Start extends Event {
	
	public Start(double time, State state,EventQueue eventQueue) {
		super(time,state,eventQueue);
		this.NAME = "start";
	}
	public abstract void run();

}