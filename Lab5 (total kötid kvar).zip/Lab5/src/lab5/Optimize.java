package lab5;

import java.util.Random;
import lab5.simulator.EventQueue;
import lab5.store.Start;
import lab5.store.Stop;
import lab5.store.StoreStateDålig;
import lab5.store.StoreView;
import lab5.Options; //???
import lab5.simulator.Simulator;

public class Optimize {
	private static int missed;

	public static void main(String[] args) {

		int klar = metod_2();
		System.out.println("BÃ¤sta antalet kassor som minskar missade Ã¤r" + missed + klar);
	}

	/**
	 * metod_1() kÃ¶r en simulering dÃ¤r alla parametrar Ã¤r fixerade. simuleringen
	 * Ã¤r densamma som huvudprogrammet runsim
	 * 
	 * @return SluttillstÃ¥ndet state.
	 */
	public static StoreStateDålig metod_1() {
		EventQueue eventQueue= new EventQueue();
		StoreStateDålig storeState = new StoreStateDålig();
		StoreView storeView = new StoreView(storeState);
		eventQueue.addEvent(new Start(Options.getStartTime(), storeState, eventQueue));
		eventQueue.addEvent(new Stop(Options.getStopTime(), storeState, eventQueue));
		
		storeState.flag = true;
		storeView.printStart();
		new Simulator(eventQueue, storeState);
		storeView.printSummary();
		
		return storeState;  
	}

	/**
	 * Metod_2() ska genom flera kÃ¶rda simuleringar med hjÃ¤lp av antal kassor
	 * minimera antalet missed antal missade Ã¤r en avtagande funktion i antal
	 * kassor
	 * 
	 * @return optimerad antal kassor.
	 */
	public static int metod_2() {
		int antalkassor = 0; // bÃ¶rjar med att sÃ¤tta antal kassor = 0
		int optimized = Integer.MAX_VALUE; // bÃ¤sta antalet kassor

		for (int i = 1; i <= Options.getCustomersMax(); i++) { // om stÃ¶rsta antalet mÃ¤nniskor i affÃ¤ren => i
			i = Options.getCashierMax(); // lika mÃ¥nga kassor som maximalt ryms mÃ¤nniskor
			StoreStateDålig state = metod_1(); // anvÃ¤nder metod 1

			// if(state.getCustomersMissedCurrent() == 0) { // om ingen kund missas
			// antalkassor = i; // maximalt människor som ryms
			// missed = state.getCustomersMissedCurrent();
			// break;
			if (state.getCustomersMissedCurrent() < optimized) {
				optimized = state.getCustomersMissedCurrent();
				antalkassor = i;
			} else if (i > 0.1 * optimized + antalkassor && state.getCustomersMissedCurrent() == optimized) {
				break;
				// optimized = state.getCustomersMissedCurrent();
				// antalkassor = i;
				// missed = state.getCustomersMissedCurrent();
			}
		}
		return antalkassor;
	}

	/**
	 * Metoden runnar metod_2() fÃ¶r att ta reda pÃ¥ bÃ¤sta mÃ¶jliga antal kassor
	 * mha slumpmÃ¤ssigt genererade tal .
	 * 
	 * @param seed fÃ¶r slumpmÃ¤ssig generering.
	 * @return bÃ¤sta mÃ¶jliga antal kassor.
	 */
	public static int metod_3(long seed) { // tar frÃ¶ som argument
		Random fro = new Random(seed); // variabel av typen random
		int calculator = 0; // loopar tills calc / antalet kassor Ã¤r 1
		int antal = 0; // antalet
		int maxantal = 0; // maxantalet

		while (true) {
			if (calculator == 100) { // bryt loopen nÃ¤r vi nÃ¥r 100
				break;
			}
			Options.seed = fro.nextInt(10000); // psuedorandom genererad int
			antal = metod_2(); // metod 2 kÃ¶rs

			if (antal > maxantal) { // sÃ¥ lÃ¤nge antalet Ã¤r stÃ¶rre Ã¤n maxantalet resetar vi calc till 0
				maxantal = antal;
				calculator = 0;
			} else {
				calculator++; // annars +1 tills vi nÃ¥r 100
			}
		}
		return maxantal; // return maxantalet
	}
}