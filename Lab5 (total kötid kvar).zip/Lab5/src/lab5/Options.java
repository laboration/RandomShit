package lab5;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public class Options {
	static int cashierMax = 2;
	static int peopleMax = 5;
	
	// Tid mellan nya customers
	static double lambda = 1.0;
	
	// Tid att plocka varor
	static double plockMax = 1.0;
	static double plockMin = 0.5;
	
	// Tid att betala
	static double payMax = 3.0;
	static double payMin = 2.0;
	
	// Seed
	static int seed = 1234;
	
	// Time
	static double stopTime = 999;
	static double closeTime = 10.0;
	static double startTime = 0;
	
	/**
	 * Returnerar det maximala antalet kassor
	 * @return
	 */
	public static int getCashierMax(){
		return cashierMax;
	}
	
	/**
	 * Returnerar "fröt"
	 * @return
	 */
	public static int getSeed() {
		return seed;
	}
	
	/**
	 * Returnerar den exponeltiala slumpmässiga parametern lambda
	 * @return
	 */
	public static double getLambda() {
		return lambda;
	}
	
	/**
	 * Returnerar stopptiden
	 * @return
	 */
	public static double getStopTime() {
		return stopTime;
	}
	
	/**
	 * Returnerar stängningstiden för snabbköpet
	 * @return
	 */
	public static double getCloseTime(){
		return closeTime;
	}
	
	/**
	 * Returnerar starttiden
	 * @return
	 */
	public static double getStartTime() {
		return startTime;
	}
	
	/**
	 * Returnerar den maximala tiden att plocka varor
	 * @return
	 */
	public static double getPlockMax() {
		return plockMax;
	}
	
	/**
	 * Returnerar den minimala tiden att plocka varor
	 * @return
	 */
	public static double getPlockMin() {
		return plockMin;
	}
	
	/**
	 * Returnerar den maximala tiden att betala
	 * @return
	 */
	public static double getPayMax() {
		return payMax;
	}
	
	/**
	 * Returnerar den minimala tiden att betala
	 * @return
	 */
	public static double getPayMin() {
		return payMin;
	}
	
	/**
	 * Returnerar den maximala mängden tillåtna kunder
	 * @return
	 */
	public static int getPeopleMax() {
		return peopleMax;
	}

}