package lab5.store;

import lab5.random.ExponentialRandomStream;
import lab5.random.UniformRandomStream;
import lab5.simulator.State;
import lab5.Options;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 *
 * Skapar specifika tillstånd för snabbköpet
 *
 */
public class StoreState extends State {
	//Variabler++
	private boolean open, pastOpen;
	private int usableCashiers = Options.getCashierMax(), pastUsableCashiers = Options.getCashierMax();
	private int ppl = 0, pastPpl;
	private int done = 0, pastDone;
	private int missed = 0, pastMissed;
	private int amountQueued, pastAmountQueued;
	private double timeQueued, timeEmptyCashier;
	private int currentQueue, pastQueue;
	private double timeLastEvent;

	private Customer pastCustomer;
	private boolean lastCustomerDenied;
	private String pastEvent;

	private ExponentialRandomStream exponential = new ExponentialRandomStream(Options.getLambda(), Options.getSeed());
	private UniformRandomStream uniformPlock = new UniformRandomStream(Options.getPlockMin(), Options.getPlockMax(),
			Options.getSeed());
	private UniformRandomStream uniformPay = new UniformRandomStream(Options.getPayMin(), Options.getPayMax(),
			Options.getSeed());

	private CustomerConstructor Constructor = new CustomerConstructor();

	private FIFO payQueue = new FIFO();
	private String pastPayQueue = payQueue.toString();

	private ArrivalTimeCreator arrivalTimeCreator = new ArrivalTimeCreator();
	private ShoppingTimeCreator shoppingTimeCreator = new ShoppingTimeCreator();
	private CheckoutTimeCreator checkoutTimeCreator = new CheckoutTimeCreator();

	/**
	 * Tom metod som skapar tillståndet
	 */
	public StoreState() {
	}
	
	
	//--------------------------------Open/closed------------------------------
	
	/**
	 * Undersöker om snabbköpet är öppet eller inte
	 * 
	 * @return true/false, där öppet = true
	 */
	public boolean isOpen() {
		return open;
	}

	/**
	 * Lagrar värdet på open i den dynamiska variabeln this.open
	 * 
	 * @param open true/false beroende på vad som ska tillsättas
	 */
	public void setOpen(boolean open) {
		this.open = open;
	}
	
	/**
	 * Returnerar om snabbköpet var öppet eller stängt tidigare
	 * 
	 * @return
	 */
	public boolean getPastOpen() {
		return pastOpen;
	}

	
	//--------------------------------Cashier------------------------------
	
	/**
	 * Ökar antalet tillgängliga kassor
	 */
	public void increaseUsableCashiers() {
		if (usableCashiers < Options.getCashierMax()) {
			usableCashiers++;
		}
	}

	/**
	 * Minskar antalet tillgängliga kassor
	 */
	public void decreaseUsableCashiers() {
		if (usableCashiers > 0) {
			usableCashiers--;
		}
	}
	
	/**
	 * Returnerar mängden tillgängliga kassor just nu
	 * 
	 * @return
	 */
	public int getUsableCashiers() {
		return usableCashiers;
	}
	
	/**
	 * Returnerar den tidigare mängden tillgängliga kassor
	 * 
	 * @return
	 */
	public int getPastUsableCashiers() {
		return pastUsableCashiers;
	}

	/**
	 * Returnerar tiden kassorna stått utan kunder
	 * 
	 * @return
	 */
	public double getTimeEmptyCashier() {
		return timeEmptyCashier;
	}
	
	/**
	 * Tar tidsskillnaden mellan de olika lasteventsen multiplicerat med kassor utan
	 * kunder och ökar den totala tiden för tomma kassor
	 */
	public void increaseTimeEmptyCashier() {
		timeEmptyCashier += (getTimeCurrent() - getTimePast()) * getPastUsableCashiers();
	}
	
	
	
	//---------------------------Customer------------------------------
	
	/**
	 * Skapar en ny kund som returneras
	 * 
	 * @return
	 */
	public Customer createCustomer() {
		return Constructor.newCustomer();
	}

	/**
	 * Returnerar den förra kunden
	 * 
	 * @return
	 */
	public Customer getPastCustomer() {
		return pastCustomer;
	}

	/**
	 * Lagrar den förra kunden i pastCustomer
	 * 
	 * @param pastCustomer parameter för den förra kunden
	 */
	public void setPastCustomer(Customer pastCustomer) {
		this.pastCustomer = pastCustomer;
	}
	
	/**
	 * Kollar om senaste kunder inte blev insläppt
	 * 
	 * @return
	 */
	public boolean getLastCustomerDenied() {
		return lastCustomerDenied;
	}

	/**
	 * Sätter den dynamiska variabeln this.lastCustomerDenied till true/false
	 * beroende på situationen
	 * 
	 * @param status true/false
	 */
	public void setLastCustomerDenied(boolean status) {
		this.lastCustomerDenied = status;
	}

	
	
	//-----------------------------Event------------------------------
	
	/**
	 * Returnerar det förra eventet
	 * 
	 * @return
	 */
	public String getPastEvent() {
		return pastEvent;
	}

	/**
	 * Lagrar det förra eventet i pastEvent
	 * 
	 * @param pastEvent Tar det förra eventets namn
	 */
	public void setPastEvent(String pastEvent) {
		this.pastEvent = pastEvent;
	}


	/**
	 * Returnerar tidpunkten för det senast genomförda eventet
	 * 
	 * @Return
	 */
	public double getTimeLastEvent() {
		return timeLastEvent;
	}
	
	
	
	//------------------------------Queue------------------------------

	/**
	 * Returnerar dend tidigare mängden kunder som köade
	 * 
	 * @return
	 */
	public int getPastAmountQueued() {
		return pastAmountQueued;
	}
	
	/**
	 * Returnerar den totala mängden kunder som har köat
	 * 
	 * @return
	 */
	public int getAmountQueued() {
		return amountQueued;
	}

	/**
	 * Ökar mängden kunder som har köat
	 */
	public void increaseQueued() {
		amountQueued++;
	}

	/**
	 * Returnerar tiden som kunder har köat
	 * 
	 * @return
	 */
	public double getTimeQueue() {
		return timeQueued;
	}

	/**
	 * Returnerar storleken på kön just nu
	 * 
	 * @return
	 */
	public int getQueueSize() {
		return payQueue.size();
	}
	
	/**
	 * Returnerar den tidigare storleken på kön
	 * 
	 * @return
	 */
	public int getPastQueueSize() {
		return pastQueue;
	}


	/**
	 * Returnerar den nuvarande kön
	 * 
	 * @return
	 */
	public int getCurrentQueue() {
		return currentQueue;
	}

	/**
	 * Returnerar den nuvarande kassakön
	 * 
	 * @return
	 */
	public FIFO getPayQueue() {
		return payQueue;
	}

	/**
	 * Returnerar den tidigare kassakön
	 * 
	 * @return
	 */
	public String getPastpayQueue() {
		return pastPayQueue;
	}


	/**
	 * Tar tidsskillnaden mellan de olika lasteventsen multiplicerat med köstorleken
	 * och ökar den totala kötiden
	 */
	public void increaseQueueTime() {
		timeQueued += (getTimeCurrent() - getTimePast()) * getPastQueueSize();
	}

	
	
	//-------------------------People---------------------------
	
	/**
	 * Returnerar hur mång akunder som befinner sig i snabbköpet just nu
	 * 
	 * @return
	 */
	public int getPpl() {
		return ppl;
	}

	/**
	 * Returnerar den tidigare mängden kunder i snabbköpet
	 * 
	 * @return
	 */
	public int getPastPpl() {
		return pastPpl;
	}

	/**
	 * Lägger till en kund som befinner sig i snabbköpet
	 */
	public void increasePpl() {
		ppl++;
	}

	/**
	 * Tar bort en kund ur snabbköpet
	 */
	public void decreasePpl() {
		ppl--;
	}
	
	//------------------------Done/Missed---------------------------

	/**
	 * Returnerar hur många kunder som betjänats just nu (vid den tidpunkten)
	 * 
	 * @return
	 */
	public int getDone() {
		return done;
	}

	/**
	 * Ökar antalet kunder som betjänats med en
	 */
	public void increaseDone() {
		done++;
	}

	/**
	 * Returnerar den tidigare mängden kunder som betjänats
	 * 
	 * @return
	 */
	public int getPastDone() {
		return pastDone;
	}

	/**
	 * Returnerar mängden missade kunder just nu
	 * 
	 * @return
	 */
	public int getMissed() {
		return missed;
	}

	/**
	 * Ökar antalet missade kunder med en
	 */
	public void increaseMissed() {
		missed++;
	}

	/**
	 * Returnerar den tidigare mängden missade kunder
	 * 
	 * @return
	 */
	public int getPastMissed() {
		return pastMissed;
	}


	// ------------------------------Tidsgeneratorer-----------------------------------

	/**
	 * Returnerar en ny ankomsttid
	 * 
	 * @return
	 */
	public double getUniqueArrivalTime() {
		return arrivalTimeCreator.getUniqueArrivalTime();
	}

	/**
	 * Returnerar en ny Shoppingtid (plocktid)
	 * 
	 * @return
	 */
	public double getUniqueShoppingTime() {
		return shoppingTimeCreator.getUniqueShoppingTime();
	}

	/**
	 * Returnerar en ny betalningstid
	 * 
	 * @return
	 */
	public double getUniqueCheckoutTime() {
		return checkoutTimeCreator.getUniqueCheckoutTime();
	}


	/**
	 * Kollar om snabbköpet är fullt eller inte
	 * 
	 * @return
	 */
	public boolean pplNotMax() {
		if (ppl == Options.getPplMax()) {
			return false;
		} else {
			return true;
		}
	}

	
	
	//-----------------------------Update------------------------------
	
	/**
	 * Uppdaterar alla värden på föregångna event till de event som just skedde (om
	 * snabbköpet är öppet). Detta sker innan nästa event sker och fortsätter
	 * succesivt så att man vet vad som hände innan och vad som händer nu
	 */
	public void updateEvent() {

		// Uppdaterar inte om stop
		if (!flag) {
		}
		// Räknar inte med de arrivals som händer om snabbköpet är fullt
		if (pastEvent == "ARRIVAL" && lastCustomerDenied) {
			increaseQueueTime();
			increaseTimeEmptyCashier();
			timeLastEvent = getTimeCurrent();

		} else { // Specialfall där man inte vill uppdatera kötid och tom-kassatid
			if (!open && pastEvent == "ARRIVAL" && pastPpl == 0) {
				setChanged();
				notifyObservers();

			} else {

				increaseTimeEmptyCashier();
				increaseQueueTime();
				setChanged();
				notifyObservers();
				timeLastEvent = getTimeCurrent();
			}
		}

		// Här ändras alla past-Events till det som just skedde
		pastOpen = open;
		pastUsableCashiers = usableCashiers;
		pastPpl = ppl;
		pastDone = done;
		pastMissed = missed;
		pastQueue = payQueue.size();
		pastPayQueue = payQueue.toString();
		pastAmountQueued = amountQueued;
		

	}

	/**
	 * Skapar en ny kund med ett eget ID som sedan returneras
	 */
	private class CustomerConstructor {

		public int ID;

		public Customer newCustomer() {
			Customer customer = new Customer(ID);
			ID = ID + 1;
			return customer;
		}
	}
	
	
	//------------------------------Inbyggda klasser för tid------------------------------

	/**
	 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
	 * Intern klass som genererar nya ankomsttider
	 */
	private class ArrivalTimeCreator {

		private double arrivalTime = 0.0;
		private double lastArrivalTime;

		/**
		 * Returnerar en unik ankomsttid
		 * 
		 * @return
		 */
		public double getUniqueArrivalTime() {
			arrivalTime = lastArrivalTime + exponential.next();
			lastArrivalTime = arrivalTime;
			return arrivalTime;
		}
	}

	/**
	 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
	 * Intern klass som generarar nya Shoppingtider
	 */
	private class ShoppingTimeCreator {

		private double shoppingTime = 0.0;

		/**
		 * Returnerar en unik shoppingtid
		 * 
		 * @return
		 */
		public double getUniqueShoppingTime() {

			shoppingTime = getTimeCurrent() + uniformPlock.next();
			return shoppingTime;
		}
	}

	/**
	 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
	 * Intern klass som generarar nya checkouttider
	 */
	private class CheckoutTimeCreator {

		private double checkoutTime = 0.0;

		/**
		 * Returnerar en unik checkouttid
		 * 
		 * @return
		 */
		public double getUniqueCheckoutTime() {

			checkoutTime = getTimeCurrent() + uniformPay.next();
			return checkoutTime;
		}
	}

}
