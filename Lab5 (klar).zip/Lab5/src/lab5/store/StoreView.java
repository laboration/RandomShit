package lab5.store;

import lab5.simulator.View;

import java.util.Observable;
import java.util.Observer;

import lab5.Options;
import lab5.store.StoreState;

import java.text.DecimalFormat;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 * En klass som skriver ut allt för vår specifika view för snabbköpssimuleringen
 */
public class StoreView extends View implements Observer {
	
	private StoreState state;
	private DecimalFormat decimalFormat1 = new DecimalFormat("0.00");
	private DecimalFormat decimalFormat2 = new DecimalFormat("0.0");
	
	/**
	 * Konstruktor som sparar tillståndet state
	 * @param state tillstånd
	 */
	public StoreView(StoreState state) {
		super(state);
		this.state = state;
		state.addObserver(this);
	}

	public void update(Observable arg0, Object arg1) {	
		printEvents();
	}
	
	/**
	 * Skriver ut alla parametrar
	 */
	public void printStart() {
			System.out.println("PARAMETRAR");
			System.out.println("==========");
			System.out.println("Antal kassor, N.......: "+Options.getCashierMax());
			System.out.println("Max som rymms, M.......: "+Options.getPplMax());
			System.out.println("Ankomsthastighet, lambda......: "+decimalFormat2.format(Options.getLambda()));
			System.out.println("Plocktider[P_min..Pmax] ["+Options.getPlockMin()+".."+Options.getPlockMax()+"]");
			System.out.println("Betaltider[K_min..Kmax] ["+Options.getPayMin()+".."+Options.getPayMax()+"]");
			System.out.println("Frö,f  "+Options.getSeed());
			System.out.println("");
			System.out.println("FÖRLOPP  ");
			System.out.println("=======");
			System.out.println("Tid\tHändelse \tKund\t?\tled\tledT\tKunder\tTot\tMissade\tköat\tKöatT\tköar\t[Kassakö..]");
			System.out.println(decimalFormat1.format(Options.getStartTime())+"  "+"\t START");
		}		

			
	/**
	 * Skriver ut alla event
	 */
	public void printEvents() {
		if(state.getPastEvent() == "CLOSING") {
			
			System.out.println(
					decimalFormat1.format(state.getTimeCurrent())+ 
					"\t"+state.getPastEvent()+"  "+
					"\t"+"-"+
					"\t"+state.getPastOpen()+
					"\t"+state.getPastUsableCashiers()+
					"\t"+decimalFormat1.format(state.getTimeEmptyCashier())+"  "+
					"\t"+state.getPastPpl()+
					"\t"+state.getPastDone()+
					"\t"+state.getPastMissed()+
					"\t"+state.getPastAmountQueued()+
					"\t"+decimalFormat1.format(state.getTimeQueue())+
					"\t"+state.getPastQueueSize()+
					"\t["+state.getPastpayQueue().toString()+"]"
				);
			
		} else if (state.getPastEvent() != null){
		
		System.out.println(
				decimalFormat1.format(state.getTimeCurrent())+ 
				"\t"+state.getPastEvent()+"  "+
				"\t"+state.getPastCustomer().findCustomer()+
				"\t"+state.isOpen()+
				"\t"+state.getPastUsableCashiers()+
				"\t"+decimalFormat1.format(state.getTimeEmptyCashier())+"  "+
				"\t"+state.getPastPpl()+
				"\t"+state.getPastDone()+
				"\t"+state.getPastMissed()+
				"\t"+state.getPastAmountQueued()+
				"\t"+decimalFormat1.format(state.getTimeQueue())+
				"\t"+state.getPastQueueSize()+
				"\t["+state.getPastpayQueue()+"]"
			);
		}		
		
	}
	
	/**
	 * Skriver ut vid stängning 
	 */
	public void printClosing() {
		System.out.println("TID  "+"HÄNDELSE  ");
	}
	
	
	/**
	 * Skriver ut resultatet
	 */
	public void printSummary() {
		
		System.out.println(decimalFormat1.format(Options.getStopTime())+"\tStop");
		System.out.println("");
		System.out.println("RESULTAT");
		System.out.println("========");
		System.out.println(
		"1) Av "+
		//totalt antal kunder
		(state.getDone()+state.getMissed())
		+" kunder handlade "
		//antal kunder som handlat
		+state.getDone()
		+" medan "
		//antal kunder som missades
		+state.getMissed()
		+" missades."
				);
		System.out.println("");
		System.out.println(
		"2) Total tid "
		//antal kassor lediga
		+Options.getCashierMax()
		+" kassor varit lediga: "
		//total tid dom kassor varit lediga
		+decimalFormat1.format(state.getTimeEmptyCashier())
		+" te. \n"
		+"   Genomsnittlig ledig kassatid: "
		//Genomsnittlig tid
		+decimalFormat1.format(state.getTimeEmptyCashier()/state.getUsableCashiers())
		+" te (dvs "
		+decimalFormat1.format(100*(state.getTimeEmptyCashier()/Options.getCashierMax()/state.getTimeLastEvent()))
		+"% av tiden från öppning tills sista kunden betalat). \n"
				);
		System.out.println(
		"3) Total tid "
		+state.getAmountQueued()
		+" kunder tvingats köa: "
		+decimalFormat1.format(state.getTimeQueue())
		+" te. \n"
		+"   Genomsnittlig kötid: "
		+decimalFormat1.format(state.getTimeQueue()/state.getAmountQueued())
		+" te."
		
				);	
		
	}
	
}
