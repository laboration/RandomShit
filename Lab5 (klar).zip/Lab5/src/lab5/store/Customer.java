package lab5.store;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *  Skapar en customer med ett eget id-nummer
 */
public class Customer {
	private int ID;

	Customer(int id) {
		ID = id;
	}

	public int findCustomer() {
		return ID;
	}
}