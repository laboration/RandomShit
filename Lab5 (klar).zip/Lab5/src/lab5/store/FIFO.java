package lab5.store;

import java.util.ArrayList;
import java.util.List;

import java.util.NoSuchElementException;

import lab5.store.Customer;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 * En klass som skapar en First In First Out-kö (FIFO)
 */
public class FIFO {

	private List<Customer> Queue = new ArrayList<Customer>(); // skapar en Customer queue (kö)

	private static int maximumSize = 0;

	/**
	 * Returnerar dete första elementet i kön
	 * 
	 * @return
	 * @throws NoSuchElementException
	 */
	public Customer first() throws NoSuchElementException {
		if (Queue.isEmpty()) {
			throw new NoSuchElementException("FIFO-Queue är tom");
		} else {
			return Queue.get(0); // Retunerear första elementet i Queue
		}
	}

	/**
	 * Lägger till en ny customer i kön
	 * 
	 * @param arg0 en customer
	 */
	public void add(Customer arg0) {
		Queue.add(arg0);

		if (Queue.size() < maxSize()) {
			maximumSize = Queue.size();

		}
	}

	/**
	 * Kollar om kön är tom eller inte
	 * 
	 * @return
	 */
	public boolean isEmpty() {
		if (Queue.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Returnerar maxstorleken på kön
	 * 
	 * @return
	 */
	public int maxSize() {
		return maximumSize;

	}

	/**
	 * Tar bort det första elementet i kön
	 * 
	 * @throws NoSuchElementException
	 */
	public void removeFirst() throws NoSuchElementException {
		if (Queue.isEmpty()) {
			throw new NoSuchElementException("FIFO-Queue är tom");
		} else {
			Queue.remove(0);
		}

	}

	/**
	 * Returnerar storleken på den nuvarande kön
	 * 
	 * @return
	 */
	public int size() {
		return Queue.size();
	}

	/**
	 * Returnerar ID av Customer i Queue i form av Strängar.
	 */
	public String toString() {
		int length = Queue.size();
		String QueueString = "";
		Customer Component;
		int ID;
		for (int i = 0; i < length; i++) {
			Component = Queue.get(i);
			ID = Component.findCustomer();
			QueueString = QueueString + String.valueOf(ID);
			if (i + 1 < length) {
				QueueString += ", ";
			}
		}

		return QueueString;
	}
}