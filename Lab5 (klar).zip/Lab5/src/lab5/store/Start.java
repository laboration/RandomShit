package lab5.store;

import lab5.Options;
import lab5.simulator.Event;
import lab5.simulator.EventQueue;
import lab5.simulator.State;
import lab5.store.events.StoreOpen;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 * En generell klass för ett event Start som startar simuleringen
 */
public class Start extends Event {

	/**
	 * Konsturktor som kallar på superkonstruktorn från Event och sätter eventets
	 * namn till "START"
	 * 
	 * @param time       tid
	 * @param state      tillstånd
	 * @param eventQueue eventkö
	 */
	public Start(double time, State state, EventQueue eventQueue) {
		super(time, state, eventQueue);
		this.NAME = "START";
	}

	public void run() {
		StoreState storeState = (StoreState) state;
		eventQueue.addEvent(new StoreOpen(Options.getStartTime(), storeState, eventQueue));
	}

}