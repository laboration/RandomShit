package lab5;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public class Options {


	static int cashierMax = 2;
	static int peopleMax = 5;
	
	static double plockMax = 1.0;
	static double plockMin = 0.5;
	
	static double payMax = 3.0;
	static double payMin = 2.0;
	
	static double lambda = 1.0;
	
	static int seed = 1234;
	
	static double stopTime = 999.00;
	static double closeTime = 10.0;
	static double startTime = 0;

	// ---------------get-Metoder

	/**
	 * Returnerar det maximala antalet kassor
	 * 
	 * @return
	 */
	public static int getCashierMax() {
		return cashierMax;
	}

	/**
	 * Lagrar ett värde cashier som max antal kassor
	 * 
	 * @param cashier antal
	 */
	public static void setCashierMax(int cashier) {
		cashierMax = cashier;
	}

	/**
	 * Returnerar "fröt"
	 * 
	 * @return
	 */
	public static int getSeed() {
		return seed;
	}

	/**
	 * Lagrar ett frö newSeed som seed
	 * 
	 * @param newSeed frö
	 */
	public static void setSeed(int newSeed) {
		seed = newSeed;
	}

	/**
	 * Returnerar den exponeltiala slumpmässiga parametern lambda
	 * 
	 * @return
	 */
	public static double getLambda() {
		return lambda;
	}

	/**
	 * Returnerar stopptiden
	 * 
	 * @return
	 */
	public static double getStopTime() {
		return stopTime;
	}

	/**
	 * Returnerar stängningstiden för snabbköpet
	 * 
	 * @return
	 */
	public static double getCloseTime() {
		return closeTime;
	}

	/**
	 * Returnerar starttiden
	 * 
	 * @return
	 */
	public static double getStartTime() {
		return startTime;
	}

	/**
	 * Returnerar den maximala tiden att plocka varor
	 * 
	 * @return
	 */
	public static double getPlockMax() {
		return plockMax;
	}

	/**
	 * Returnerar den minimala tiden att plocka varor
	 * 
	 * @return
	 */
	public static double getPlockMin() {
		return plockMin;
	}

	/**
	 * Returnerar den maximala tiden att betala
	 * 
	 * @return
	 */
	public static double getPayMax() {
		return payMax;
	}

	/**
	 * Returnerar den minimala tiden att betala
	 * 
	 * @return
	 */
	public static double getPayMin() {
		return payMin;
	}

	/**
	 * Returnerar den maximala mängden tillåtna kunder
	 * 
	 * @return
	 */
	public static int getPplMax() {
		return peopleMax;
	}

}