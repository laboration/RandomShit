package lab5.simulator;

/**
 * En generell klass för att skapa event
 * 
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public abstract class Event implements Comparable<Event> {

	protected double eventTime;
	protected State state;
	protected EventQueue eventQueue;
	protected String NAME = "EVENT";

	/**
	 * Ger varje event en tid och ett tillstånd och lägger till det i kön
	 * 
	 * @param time       tid
	 * @param state      tillstånd
	 * @param eventQueue eventkö
	 */
	public Event(double time, State state, EventQueue eventQueue) {

		this.eventTime = time;
		this.state = state;
		this.eventQueue = eventQueue;
	}

	/**
	 * Lagrar en tid för ett event i den dynamiska variabeln eventTime
	 * 
	 * @param eventTime tid
	 */
	public void setTime(double eventTime) {
		this.eventTime = eventTime;
	}

	/**
	 * Returnerar tiden för ett event
	 * 
	 * @return
	 */
	public double getTime() {
		return this.eventTime;
	}

	public int compareTo(Event e) {
		Double timeOne = new Double(eventTime);
		Double timeTwo = new Double(e.eventTime);
		return timeOne.compareTo(timeTwo);
	}

	/**
	 * Run-metod för eventen
	 */
	abstract protected void run();
}