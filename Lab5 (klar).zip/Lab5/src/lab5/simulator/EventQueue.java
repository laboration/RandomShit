package lab5.simulator;

import java.util.PriorityQueue;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan 
 * En klass som skapar en kö för alla event och hanterar dessa
 */
public class EventQueue {
	private PriorityQueue<Event> eventQueue;

	/**
	 * Skapar kön
	 */
	public EventQueue() {
		eventQueue = new PriorityQueue<Event>();
	}

	/**
	 * Lägger till ett event i kön
	 * 
	 * @param event event
	 */
	public void addEvent(Event event) {
		eventQueue.add(event);
	}

	/**
	 * Returnerar true/false beroende på om kön är tom
	 * 
	 * @return
	 */
	public boolean isEmpty() {
		return this.eventQueue.isEmpty();
	}

	/**
	 * Returnerar det första eventet i kön
	 * 
	 * @return
	 */
	public Event takeFirst() {//
		if (eventQueue.isEmpty()) {
			return null;
		}
		return eventQueue.poll();
	}

	/**
	 * Returerar storleken på kön
	 * 
	 * @return
	 */
	public int size() {
		return this.eventQueue.size();
	}
}