package lab5.simulator;

import lab5.simulator.Event;
import lab5.simulator.EventQueue;
import lab5.simulator.State;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 * En generell simulator som startar och stoppar en simulering av event
 */
public class Simulator {

	/**
	 * Konstruktor för simulatorn
	 * 
	 * @param eventQueue eventkö
	 * @param state      tillstånd
	 */
	public Simulator(EventQueue eventQueue, State state) {// metod run som ska plocka ut events på tur från eventqueue
															// och ser till att de sker genom att ropa respektive metod
		while (!(eventQueue.isEmpty())) { // så länge eventqueue inte är tom så kör den
			Event event = eventQueue.takeFirst();
			if (!state.flag) { // Om simuleringen inte är igång breakar den
				break; // break

			}
			if (event.NAME == "START") {
				event.run();

			} else if (event.NAME == "STOP") {
				event.run();

			} else {
				event.run();
				state.update();
			}
		}
	}
}