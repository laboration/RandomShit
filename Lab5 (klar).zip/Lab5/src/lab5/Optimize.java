package lab5;

import java.util.Random;
import lab5.simulator.EventQueue;
import lab5.store.Start;
import lab5.store.Stop;
import lab5.store.StoreState;
import lab5.Options; //???
import lab5.simulator.Simulator;

/**
 * @author Erik Olausson, Mikael Granström, Sermed Mutter, Amir Rakshan
 *
 */
public class Optimize {
	private int missed;

	public static void main(String[]args) {
		Optimize test = new Optimize();
		//metod 2
		int klar = test.metod_2();
		
		//metod 3
//		int klar = test.metod_3(1001010);

//		
		// sim med optimala antal kassor.
//		Options.setCashierMax(klar);
//		StoreState storeState = new StoreState();;
//		EventQueue eventQueue=  new EventQueue();		
//		StoreView storeView = new StoreView(storeState);
//		eventQueue.addEvent(new Start(Options.getStartTime(), storeState, eventQueue));
//		eventQueue.addEvent(new Stop(Options.getStopTime(), storeState, eventQueue));
//		storeState.flag = true;
//		new Simulator(eventQueue, storeState);

	}
	
	/**
	 * metod_1() kör en simulering där alla parametrar är fixerade.
	 * simuleringen är densamma som huvudprogrammet main
	 * @return Sluttillståndet state.
	 */
	public StoreState metod_1() {
		StoreState state = new StoreState();
		EventQueue eventQueue=  new EventQueue();	
		eventQueue.addEvent(new Start(Options.getStartTime(), state, eventQueue));
		eventQueue.addEvent(new Stop(Options.getStopTime(),state,eventQueue));
		
		state.flag = true;
		new Simulator(eventQueue, state);
	
		return state;
	}

	/**
	 * Metod_2() ska genom flera körda simuleringar med hjälp av antal kassor minimera antalet missed 
	 * antal missade är en avtagande funktion i antal kassor
	 * @return optimerad antal kassor.
	 */
	public int metod_2() {
		int antalkassor=0;//börjar med att sätta antal kassor = 0
		int optimized = Integer.MAX_VALUE; // lägsta antal missade kunder.

		for (int i = 1; i<=Options.getPplMax(); i++) { // om största antalet människor i affären => i
			Options.setCashierMax(i); // lika många kassor som maximalt ryms människor
			StoreState state = metod_1(); // använder metod 1 
			if (state.getMissed() < optimized ) {
				optimized = state.getMissed();
				this.missed = optimized;
				antalkassor = i;
			}else{
				continue;
			}
			
		}
		System.out.println("Bästa antalet kassor som minskar missade är: " + "(" + optimized + ")" + " " +antalkassor);
		return antalkassor;
	}
	 /**
	 * Metoden runnar metod_2() för att ta reda på bästa möjliga antal kassor mha slumpmässigt genererade tal .
	 * @param seed för slumpmässig generering.
	 * @return bästa möjliga antal kassor.
	 */
	public int metod_3(long seed) { // tar frö som argument
		Random fro = new Random(seed); //variabel av typen random
		int calculator = 0; // loopar tills calc / antalet kassor är 1
		int maxantal = 0; //maxantalet
		

		while (true) {
			if (calculator == 100) { // bryt loopen när vi når 100
				break;
			}
			Options.setSeed(fro.nextInt());// psuedorandom genererad int
			int antal = metod_2();	//metod 2 körs

			if(antal > maxantal) { //så länge antalet är större än maxantalet resetar vi calc till 0
				maxantal = antal;
				calculator = 0;
			}else{
				calculator++; // annars +1 tills vi når 100
			}
			
		}
		System.out.println("Bästa antalet kassor som minskar missade är: " + "(" + this.missed + ")" + " " +maxantal);
	
		return maxantal;	// return maxantalet
	}
}