package lab5.random;

import java.util.Random;

/**
 * En klass som genererar slumpmässiga tal exponentiellt
 */
public class ExponentialRandomStream {

	private Random rand;
	private double lambda;

	/**
	 * Skapar ett nytt slumpmässigt seed och lagrar ett värde på lambda
	 * 
	 * @param lambda lambdavärde
	 * @param seed   frö
	 */
	public ExponentialRandomStream(double lambda, long seed) {
		rand = new Random(seed);
		this.lambda = lambda;
	}

	/**
	 * Skapar ett slumpmässigt objekt och lagrar värdet på parametern lambda i den
	 * dynamiska variabeln lambda
	 * 
	 * @param lambda lambdavärde
	 */
	public ExponentialRandomStream(double lambda) {
		rand = new Random();
		this.lambda = lambda;
	}

	/**
	 * Returnerar ett nytt slumpmässigt värde
	 * 
	 * @return
	 */
	public double next() {
		return -Math.log(rand.nextDouble()) / lambda;
	}
}
