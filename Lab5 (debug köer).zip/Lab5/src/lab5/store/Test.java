package lab5.store;

import lab5.simulator.State;

public abstract class Test extends State{
	
}
